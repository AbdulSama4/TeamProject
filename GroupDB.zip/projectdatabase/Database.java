package projectdatabase;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;


public class Database {

	
public static void main(String[] args) {
	// establishing a connection to database 
	String url = "jdbc:sqlserver://sqltay2332.database.windows.net:1433;database=ProjectDatabase;user={your_username_here};password={your_password_here};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;authentication=ActiveDirectoryPassword";
	try(Connection connection = DriverManager.getConnection(url)) {
		String insertQuery = "Insert INTO Users(FirstName, LastName, Address, Zip, State, Username, Password, Email, SSN, SecurityQuestion) " + 
	     "VALUES (?,  ?,  ?,  ?,  ?, ?,  ?,  ?,  ?,  ?)";
	try(PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            preparedStatement.setString(1, "John");
            preparedStatement.setString(2, "Doe");
            preparedStatement.setString(3, "123 Main St");
            preparedStatement.setString(4, "12345");
            preparedStatement.setString(5, "CA");
            preparedStatement.setString(6, "john_doe");
            preparedStatement.setString(7, "password123");
            preparedStatement.setString(8, "john.doe@example.com");
            preparedStatement.setString(9, "123-45-6789");
            preparedStatement.setString(10, "What is your favorite color?");

            preparedStatement.executeUpdate();
            System.out.println("Data was inserted successfully.");
	}
} catch (SQLException e) {
	e.printStackTrace();
}
}
}

